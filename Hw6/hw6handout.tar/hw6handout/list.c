/* Yanling Wang Fall 2018 */
#include <stdio.h>
#include <stdlib.h>
#include "list.h"

/* print out the content of a list */
void displayList(listNode *list) {
  printf("list: ");
  while(list != NULL) {
    printf("%d ", list->value);
    list = list->next;
  }
  printf("%p\n", list);
  return;
}

/* given a pointer to the head of the list and a value,
 * add a new node with value to the head of the list */
void push(listNode **listPtr, int value) {
  listNode *newNodePtr = (listNode *)malloc(sizeof(listNode));
  newNodePtr->value = value;
  newNodePtr->next = *listPtr;
  *listPtr = newNodePtr;
  return;
}
/* remove the head of the list (and free its memory), and
 * return its value. If the list is empty, return 0 */ 
int pop(listNode **listPtr) {
  int value = 0;
  listNode *tempPtr;
  if (*listPtr) {
    tempPtr = *listPtr;
    value = tempPtr->value;
    *listPtr = tempPtr->next;
    free(tempPtr);
  }
  return value;
}

/* remove and free memory of all the element of the list. */
void destroyList(listNode **listPtr) {
  listNode *temp = *listPtr;
  while(temp != NULL) {
    *listPtr = (*listPtr) -> next;
    free(temp);
    temp = *listPtr;
  }
  return;
}

void reverse(listNode **listPtr) {
  listNode *current = *listPtr;     //set three state pointers 
  listNode *after = NULL;
  listNode *previous = NULL;
  while (current != NULL){
    after = current -> next;        //save next
    current -> next = previous;     //current node point to previous node
    previous = current;             //move all pointer one step ahead
    current = after;
  }
  *listPtr = previous;              //reset the head pointer
  return;
}

void insert(listNode **listPtr, int value) {
  listNode *newNodePtr = (listNode *)malloc(sizeof(listNode));  
  listNode *temp = *listPtr;
  newNodePtr -> value = value;
  newNodePtr -> next = NULL;        //create a new node needed to insert         
  if(*listPtr == NULL){             //special case
    *listPtr = newNodePtr;	    //if the list is empty, then the head pointer points to newNode 
    return;
  } 	
  while (temp -> next != NULL){	    //normal case
    temp = temp -> next;            //find the last node in the list, then add the newNode to the TAIL
  }
  temp -> next = newNodePtr;
  return;
}


void removeAll(listNode **listPtr, int value){
  listNode *current = *listPtr;      //set three state pointers
  listNode *after = NULL;
  listNode *previous = NULL;
  if(*listPtr == NULL)		     //if there is no nodes in the list, then return	
    return;	
  while(current -> value == value){  //if the first node is the noe that needed to remove
    after = current -> next;
    *listPtr = after;		     //reset the head pointer
    free(current);		     //remove the current node
    current = after;		     //move the state pointer one step after 
    if (current == NULL)	     //after delete, if there is no nodes in the list, then return
      return;		
  }
  if(current != NULL){		     	
    previous = current;		     //set previous state to the first node 	
    current = current -> next;       //set the current state to the second node
  }
  while (current != NULL){
    if(current -> value == value){
      after = current -> next;       //save next
      previous -> next = after;      //previous not link to current instead of after
      free(current);
      current = after;               //move current point to next pointer one step ahead
    }
    else{
      previous = current;	     //if not remove, step ahead
      current = current -> next;
    }
  }
  return;
}

int count(listNode *listPtr, int value) {
  listNode *temp = listPtr;
  int ret = 0;			//number counter
  while(temp != NULL){		//if the node is not a null node
    if( temp -> value == value) //if the value matched, counter increase one 
      ret ++;
    temp = temp -> next;	//step to next node
}

  return ret;
} 

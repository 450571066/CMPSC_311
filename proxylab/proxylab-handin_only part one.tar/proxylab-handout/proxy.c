#include <stdio.h>
#include <stdlib.h>
#include "csapp.h"

/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 16777216 
#define MAX_OBJECT_SIZE 8388608 

/* You won't lose style points for including this long line in your code */
static const char *user_agent_hdr = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0.3) Gecko/20120305 Firefox/10.0.3\r\n";
static const char *Connection_hdr = "Connection: close\r\n";
static const char *Proxy_Connection_hdr = "Proxy_Connection: close\r\n";
static const char *endline = "\r\n";

/*Double linklist*/
typedef struct listNode {
  char* buf[MAXLINE];
  char* hostname[MAXLINE];
  char* port[MAXLINE];
  int Valuesize;
  struct listNode *next;
  struct listNode *prev;
} listNode;

typedef struct doublyLinkedList {
  listNode *head;
  listNode *tail;
  int LinkedListSize;
} doublyLinkedList;
void insertHead(doublyLinkedList *listPtr, char* buf, char* hostname, char* port, int Valuesize);

void doit(int fd, char *port);
void parse_uri(char* uri, char* hostname, char* path, char* parsed_ur);
void clienterror(int fd, char *cause, char *errnum, 
		 char *shortmsg, char *longmsg);

int main(int argc, char **argv) 
{
  //    printf("%s", user_agent_hdr);
    int listenfd, connfd;
    char hostname[MAXLINE], port[MAXLINE];
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;
    
    /* Check command line args */
    if (argc != 2) {
	fprintf(stderr, "usage: %s <port>\n", argv[0]);
	exit(1);
    }
    
    Signal(SIGPIPE, SIG_IGN);
    listenfd = Open_listenfd(argv[1]);
    while (1) {
	clientlen = sizeof(clientaddr);
	connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen); //line:netp:tiny:accept
    Getnameinfo((SA *) &clientaddr, clientlen, hostname, MAXLINE, 
                    port, MAXLINE, 0);
    printf("Accepted connection from (%s, %s)\n", hostname, port);
	doit(connfd, port);                                             //line:netp:tiny:doit
	Close(connfd);                                            //line:netp:tiny:close
    }
}
/* $end tinymain */

/*
 * doit - handle one HTTP request/response transaction
 */
/* $begin doit */
void doit(int fd, char *port) 
{
  //    struct stat sbuf;
    char buf[MAXLINE], method[MAXLINE], uri[MAXLINE], version[MAXLINE];
    //    char filename[MAXLINE], cgiargs[MAXLINE];
    rio_t rio, server_rio;
    char hostname[MAXLINE], path[MAXLINE], parsed_uri[MAXLINE], new_host[MAXLINE], new_port[MAXLINE];
	char *default_port = "80";
    int i;
	int save_number = 0;
    char *save = "Host: ";
    int clientfd;
	
    /* Read request line and headers */
    rio_readinitb(&rio, fd); 
    if (!rio_readlineb(&rio, buf, MAXLINE))  //line:netp:doit:readrequest
        return;
    printf("%s", buf);
    sscanf(buf, "%s %s %s", method, uri, version);       //line:netp:doit:parserequest
	if (strcasecmp(method, "GET")) {                     //line:netp:doit:beginrequesterr
		clienterror(fd, method, "501", "Not Implemented",
                    "Tiny does not implement this method");
        return;
    }             
	else{
		
		save_number = 0;

		parse_uri(uri, hostname, path, parsed_uri);  
		strcpy(new_host, "");
		strcpy(new_port, "");
		for(i = 0; i < MAXLINE; i++){	
			new_host[i] = '\0';
		}
		for(i = 0; i < MAXLINE; i++){	
			if(hostname[i] != ':'){
				new_host[i] = hostname[i];
					//printf("host: %s,  port: %s\n", new_host, new_port);
			}else{
				save_number = i;
				break;
			}
		}
		if (save_number != 0){
			for(i = save_number + 1; i < MAXLINE; i++){	
				new_port[i - save_number - 1] = hostname[i];
			}	
		}
		else
		  strcpy(new_port, default_port);

		printf("host: %s,  port: %s", new_host, new_port);

		clientfd = Open_clientfd(new_host, new_port);

	  
		strcpy(buf, parsed_uri);
		strcat(buf, endline);
		strcat(buf, save);
		strcat(buf, new_host);
		strcat(buf, endline);
		strcat(buf, user_agent_hdr);
		strcat(buf, Connection_hdr);
		strcat(buf, Proxy_Connection_hdr);
		strcat(buf, endline);
	  
		rio_writen(clientfd, buf, strlen(buf)); 

    }                                                    //line:netp:doit:endrequesterr
      

    /*receive message from end server and send to the client*/
	Rio_readinitb(&server_rio, clientfd);
    size_t num;
	int count = 0;
//	char Save_buf[MAXLINE];
//	num = Rio_readlineb(&server_rio,buf,MAXLINE);
//	count += (int)num;
//	strcpy(Save_buf, buf);
    while((num = Rio_readlineb(&server_rio,buf,MAXLINE)) != 0)
    {
//		count += (int)num;
//		strcat(Save_buf, buf);
		printf("proxy received %d bytes,then send\n",(int)num);
        Rio_writen(fd,buf,(int)num);
    }
//	Rio_writen(fd,Save_buf,count);
//	printf("proxy received %d bytes, and send %d bytes\n",count, count);
	
	
	
    Close(clientfd);

 }
/* $end doit */

void parse_uri(char* uri, char* hostname, char* path, char* parsed_uri)
{
  int i, save = 0;
//  char getHostname[MAXLINE];
  char *Http_test = "http://";
  char *get = "GET ";
  char *Http_1 = " HTTP/1.0";
//  int length = sizeof(uri);
  
//  printf("\nUri: %s     hostname: %s      parsed_uri: %s      path:%s",uri, hostname, parsed_uri, path);
  for(i = 0; i < 7; i ++){
    if(uri[i] != Http_test[i]){
      printf("input error");
      exit(1);
    }
  }
//    printf("\nUri: %s     hostname: %s      parsed_uri: %s      path:%s",uri, hostname, parsed_uri, path);
  for(i = 0; i < MAXLINE; i++){	
      hostname[i] = '\0';
	  path[i] = '\0';
	  parsed_uri[i] = '\0';
  }
//    printf("\nUri: %s     hostname: %s      parsed_uri: %s      path:%s",uri, getHostname, parsed_uri, path);
  for(i = 7; i < MAXLINE; i++){	
    if(uri[i] != '/'){
      hostname[i-7] = uri[i];
//	  printf("\nUri: %s     hostname: %s      parsed_uri: %s      path:%s",uri, hostname, parsed_uri, path);
	}else{
      save = i;
      break;
    }
  }
//  printf("\nUri: %s     hostname: %s      parsed_uri: %s      path:%s",uri, getHostname, parsed_uri, path);
  if(save != 0){
	for(i = save; i < MAXLINE; i ++){
		if(uri[i] != ' '){
			path[i-save] = uri[i];
			parsed_uri[i-save+4] = uri[i];
		}
		else{
			save = i-save+4;
			break;
		}
	}
  }
  
 //  strcpy(hostname, getHostname);
   strcpy(parsed_uri, get);
   strcat(parsed_uri, path);
   strcat(parsed_uri, Http_1);
  
//   printf("\nUri: %s     hostname: %s      parsed_uri: %s      path:%s",uri, hostname, parsed_uri, path);
}  

void clienterror(int fd, char *cause, char *errnum, char *shortmsg, char *longmsg) 
{
    char buf[MAXLINE], body[MAXBUF];

       /* Build the HTTP response body */
    sprintf(body, "<html><title>Tiny Error</title>");
    sprintf(body, "%s<body bgcolor=""ffffff"">\r\n", body);
    sprintf(body, "%s%s: %s\r\n", body, errnum, shortmsg);
    sprintf(body, "%s<p>%s: %s\r\n", body, longmsg, cause);
    sprintf(body, "%s<hr><em>The Tiny Web server</em>\r\n", body);

       /* Print the HTTP response */
    sprintf(buf, "HTTP/1.0 %s %s\r\n", errnum, shortmsg);
    sprintf(buf, "%sContent-type: text/html\r\n", buf);
    sprintf(buf, "%sContent-length: %d\r\n\r\n", buf, (int)strlen(body));
    rio_writen(fd, buf, strlen(buf));
    rio_writen(fd, body, strlen(body));
}

/* $end clienterror */

/*Double link list*/

void insertHead(doublyLinkedList *listPtr, char* buf, char* hostname, char* port, int Valuesize) {
  listNode *temp = (listNode*)malloc(MAX_OBJECT_SIZE); 
  strcpy(temp->*buf, buf);
  strcpy(temp->*hostname, hostname);
  strcpy(temp->*port, port);
  
  //temp -> hostname = *hostname;
  //temp -> port = *port;
  temp -> Valuesize = Valuesize;
  temp -> next = NULL;   //initail the temp node
  if(listPtr -> head == NULL && listPtr -> tail == NULL)
  {
    listPtr -> head = temp;
    listPtr -> tail = temp;
  }                     //if the list is empty 
  else
  {
    listPtr -> head -> prev = temp;
    temp -> next = listPtr -> head;
    listPtr -> head = temp; 
  }                    //if the list is not empty 
  return;
}


